from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField
from wtforms.validators import InputRequired, Length, Email


# new user form
class NewUser(FlaskForm):
    username = StringField('username', validators=[InputRequired(), Length(min=1, max=20)])
    password = PasswordField('password', validators=[InputRequired(), Length(min=6, max=50)])
    email = StringField('email', validators=[InputRequired(), Email(), Length(min=1, max=50)])
    first_name = StringField('first name', validators=[InputRequired(), Length(min=1, max=30)])
    last_name = StringField('last name', validators=[InputRequired(), Length(min=1, max=30)])


# login form
class Login(FlaskForm):
    username = StringField('username', validators=[InputRequired()])
    password = PasswordField('password', validators=[InputRequired()])


# feedback form
class FeedbackForm(FlaskForm):
    title = StringField('title', validators=[InputRequired(), Length(min=1, max=100)])
    content = StringField('content', validators=[InputRequired()])
