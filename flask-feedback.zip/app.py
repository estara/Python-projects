from models import db, connect_db, User, Feedback
from forms import NewUser, Login, FeedbackForm
from flask import Flask, render_template, redirect, session, flash
from flask_debugtoolbar import DebugToolbarExtension
from sqlalchemy.exc import IntegrityError


app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql:///flask-feedback'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'foo'

toolbar = DebugToolbarExtension(app)

connect_db(app)
db.create_all()

# routes for users
# redirect to new user form
@app.route('/')
def index():
    return redirect('/register')


# new user form
@app.route('/register')
def new_user():
    if 'user_id' in session:
        return redirect(f'/users/{session["user_id"]}')
    form = NewUser()
    return render_template('newuser.html', form=form)


# handle new user form
@app.route('/register', methods=['POST'])
def make_new_user():
    form = NewUser()
    if form.validate_on_submit():
        username = form.username.data
        password = form.password.data
        email = form.email.data
        first_name = form.first_name.data
        last_name = form.last_name.data
        newuser = User.register(username, password, email, first_name, last_name)
        try:
            db.session.commit()
        except IntegrityError:
            form.username.errors.append('Username taken. Please pick another.')
            return render_template('newuser.html', form=form)
        session['user_id'] = newuser.username
        return redirect(f'/user/{username}')

    else:
        return render_template('newuser.html', form=form)


# login user
@app.route('/login', methods=['GET', 'POST'])
def login_user():
    if "user_id" in session:
        return redirect(f"/users/{session['user_id']}")
    form = Login()
    if form.validate_on_submit():
        username = form.username.data
        password = form.password.data
        loginuser = User.authenticate(username, password)
        if loginuser:
            session['user_id'] = loginuser.username
            return redirect(f'/user/{loginuser.username}')
        else:
            form.username.errors = ['Invalid username/password']
    return render_template('login.html', form=form)


# display information on logged in user and list of their feedback
@app.route('/users/<username>')
def user_info(username):
    if 'user_id' not in session or username != session['user_id']:
        flash("Not Authorized")
        return redirect("/")
    else:
        user = User.query.get_or_404(username)
        feedback = Feedback.query.filter_by(username=username)
        return render_template('userdetail.html', user=user, feedback=feedback)


# logout user
@app.route('/logout')
def logout():
    session.pop('user_id')
    return redirect('/')


# delete user
@app.route('/users/<username>/delete', methods=['POST'])
def delete_user(username):
    if 'user_id' not in session or username != session['user_id']:
        flash("Not authorized")
        return redirect("/")
    else:
        user = User.query.get_or_404(username)
        db.session.delete(user)
        db.session.commit()
        session.pop('user_id')
        return redirect('/')


# routes for feedback
# add feedback form
@app.route('/users/<username>/feedback/add')
def add_feedback(username):
    if 'user_id' not in session or username != session['user_id']:
        flash("Not authorized")
        return redirect("/")
    else:
        form = FeedbackForm()
        return render_template('addfeedback.html', form=form)


# handle add feedback form
@app.route('/users/<username>/feedback/add', methods=['POST'])
def make_add_feedback(username):
    if 'user_id' not in session or username != session['user_id']:
        flash("Not Authorized")
        return redirect("/")
    else:
        form = FeedbackForm()
        if form.validate_on_submit():
            title = form.title.data
            content = form.content.data
            newfeedback = Feedback(username=username, title=title, content=content)
            db.session.add(newfeedback)
            db.session.commit()
            return redirect(f'/users/{username}')
        else:
            return render_template('addfeedback.html', form=form)


# display edit feedback form
@app.route('/feedback/<int:feedback_id>/update')
def edit_feedback(feedback_id):
    feedback = Feedback.query.get_or_404(feedback_id)
    if 'user_id' not in session or feedback.username != session['user_id']:
        flash("Not authorized")
        return redirect("/")
    else:
        form = FeedbackForm(obj=feedback)
        return render_template('editfeedback.html', feedback=feedback, form=form)


# handle edit feedback form
@app.route('/feedback/<int:feedback_id>/update', methods=['POST'])
def make_edit_feedback(feedback_id):
    feedback = Feedback.query.get_or_404(feedback_id)
    if 'user_id' not in session or feedback.username != session['user_id']:
        flash("Not authorized")
        return redirect("/")
    else:
        form = FeedbackForm(obj=feedback)
        if form.validate_on_submit():
            feedback.title = form.title.data
            feedback.content = form.content.data
            db.session.commit()
            return redirect(f'/users/{feedback.username}')
        else:
            return render_template('editfeedback.html', form=form, feedback=feedback)


# delete feedback
@app.route('/feedback/<int:feedback_id>/delete', methods=['POST'])
def delete_feedback(feedback_id):
    feedback = Feedback.query.get_or_404(feedback_id)
    if 'user_id' not in session or feedback.username != session['user_id']:
        flash("Not authorized")
        return redirect("/")
    else:
        db.session.delete(feedback)
        db.session.commit()
    return redirect(f'/users/{feedback.username}')



