from models import User, db, Feedback


db.drop_all()
db.create_all()

User.query.delete()
Feedback.query.delete()

johnny = User(first_name="John", last_name="Smith", email="testuser@email.com", password="foo123", username="testuser1")

db.session.add(johnny)
db.session.commit()
