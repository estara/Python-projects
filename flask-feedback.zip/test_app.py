from unittest import TestCase
from app import app
from models import db, User
from flask import session

# Use test database
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql:///foo-test'
app.config['SQLALCHEMY_ECHO'] = False

# Make Flask errors be real errors, rather than HTML pages with error info
app.config['TESTING'] = True

db.drop_all()
db.create_all()

USER_DATA = {
    "username": "TestUser1",
    "password": "pass1",
    "email": "TestUser1@email.com",
    "first_name": "Test1",
    "last_name": "User1"
}

USER_DATA2 = {
    "username": "TestUser2",
    "password": "pass2",
    "email": "TestUser2@email.com",
    "first_name": "Test2",
    "last_name": "User2"
}

USER_DATA3 = {
    "username": "TestUser3",
    "password": "pass3",
    "email": "TestUser3@email.com",
    "first_name": "Test3",
    "last_name": "User3"
}


class UsersTestCase(TestCase):

    def setUp(self):
        """Make demo data."""

        User.query.delete()

        user = User(**USER_DATA)
        db.session.add(user)
        db.session.commit()

        self.user = user

    def tearDown(self):
        """Clean up fouled transactions."""

        db.session.rollback()

    def test_new_user(self):
        with app.test_client() as client:
            resp = client.get("/register")
            html = resp.get_data(as_text=True)
            self.assertEqual(resp.status_code, 200)
            self.assertIn('<form id="newuser" method="POST">', html)

    def test_user_info(self):
        with app.test_client() as client:
            url = f"/users/{self.user.username}"
            resp = client.get(url)
            # html = resp.get_data(as_text=True)
            self.assertEqual(resp.status_code, 302)

