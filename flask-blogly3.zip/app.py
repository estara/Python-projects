"""Blogly application."""

from flask import Flask, redirect, render_template, request
from flask_debugtoolbar import DebugToolbarExtension
from models import db, connect_db, User, Post, Tag, PostTag

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql:///blogly'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'foo'

toolbar = DebugToolbarExtension(app)

connect_db(app)
db.create_all()

# routes for users


@app.route('/')
def index():
    postlist = Post.query.all()
    taglist = Tag.query.all()
    return render_template('index.html', posts=postlist, tags=taglist)


@app.route('/users')
def listusers():
    userlist = User.query.all()
    return render_template('/userlisting.html', users=userlist)


@app.route('/users/new')
def newuser():
    return render_template('/newuser.html')


@app.route('/users/new', methods=['POST'])
def adduser():
    first = request.form['first']
    last = request.form['last']
    url = request.form['url']
    user = User(first_name=first, last_name=last, image_url=url)
    db.session.add(user)
    db.session.commit()
    return redirect('/users')


@app.route('/users/<int:userid>')
def userdetail(userid):
    user = User.query.get_or_404(userid)
    postlist = Post.query.filter(Post.created_by == userid)
    return render_template('/userdetail.html', user=user, posts=postlist)


@app.route('/users/<int:userid>/edit')
def edituser(userid):
    user = User.query.get_or_404(userid)
    return render_template('/edituser.html', user=user)


@app.route('/users/<int:userid>/edit', methods=['POST'])
def makeedit(userid):
    user = User.query.get_or_404(userid)
    user.first_name = request.form['first']
    user.last_name = request.form['last']
    user.image_url = request.form['url']
    db.session.add(user)
    db.session.commit()
    return redirect('/users')


@app.route('/users/<int:userid>/delete', methods=['POST'])
def deleteuser(userid):
    user = User.query.get_or_404(userid)
    db.session.delete(user)
    db.session.commit()
    return redirect('/users')

# routes for posts


@app.route('/users/<int:userid>/posts/new')
def newpost(userid):
    user = User.query.get_or_404(userid)
    taglist = Tag.query.all()
    return render_template('/newpost.html', user=user, tags=taglist)


@app.route('/users/<int:userid>/posts/new', methods=['POST'])
def addpost(userid):
    user = User.query.get_or_404(userid)
    title = request.form['title']
    content = request.form['content']
    tags = [int(num) for num in request.form.getlist('tagbox')]
    taglist = Tag.query.filter(Tag.id.in_(tags)).all()
    post = Post(title=title, content=content, user=user, tag=taglist)
    db.session.add(post)
    db.session.commit()
    return redirect(f'/users/{userid}')


@app.route('/posts/<int:postid>')
def postdetail(postid):
    post = Post.query.get_or_404(postid)
    taglist = PostTag.query.filter(PostTag.post_id == postid)
    return render_template('/postdetail.html', post=post, tags=taglist)


@app.route('/posts/<int:postid>/edit')
def editpost(postid):
    post = Post.query.get_or_404(postid)
    taglist = Tag.query.all()
    return render_template('/editpost.html', post=post, tags=taglist)


@app.route('/posts/<int:postid>/edit', methods=['POST'])
def makepostedit(postid):
    post = Post.query.get_or_404(postid)
    post.title = request.form['title']
    post.content = request.form['content']
    tags = [int(num) for num in request.form.getlist('tagbox')]
    post.tags = Tag.query.filter(Tag.id.in_(tags)).all()
    db.session.add(post)
    db.session.commit()
    return redirect(f'/posts/{postid}')


@app.route('/posts/<int:postid>/delete', methods=['POST'])
def deletepost(postid):
    post = Post.query.get_or_404(postid)
    db.session.delete(post)
    db.session.commit()
    return redirect('/users')

# routes for tags


@app.route('/tags')
def listtags():
    taglist = Tag.query.all()
    return render_template('/listtag.html', tags=taglist)


@app.route('/tags/<int:tagid>')
def tagdetail(tagid):
    tag = Tag.query.get_or_404(tagid)
    postlist = PostTag.query.filter(PostTag.tag_id == tagid)
    return render_template('/tagdetail.html', posts=postlist, tag=tag)


@app.route('/tags/new')
def newtag():
    return render_template('/newtag.html')


@app.route('/tags/new', methods=['POST'])
def addtag():
    name = request.form['tagname']
    tag = Tag(name=name)
    db.session.add(tag)
    db.session.commit()
    return redirect('/tags')


@app.route('/tags/<int:tagid>/edit')
def edittag(tagid):
    tag = Tag.query.get_or_404(tagid)
    return render_template('/edittag.html', tag=tag)


@app.route('/posts/<int:tagid>/edit', methods=['POST'])
def maketagedit(tagid):
    tag = Tag.query.get_or_404(tagid)
    tag.name = request.form['tagname']
    db.session.add(tag)
    db.session.commit()
    return redirect('/tags')


@app.route('/tags/<int:tagid>/delete', methods=['POST'])
def deletetag(tagid):
    tag = Tag.query.get_or_404(tagid)
    db.session.delete(tag)
    db.session.commit()
    return redirect('/tags')
