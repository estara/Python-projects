"""Flask app for Cupcakes"""
from models import db, connect_db, Cupcake
from flask import Flask, render_template, jsonify, request
from flask_debugtoolbar import DebugToolbarExtension


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql:///cupcakes'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'foo'

toolbar = DebugToolbarExtension(app)

connect_db(app)
db.create_all()


# serialize a cupcake SQLAlchemy obj to dictionary
def serialize_cupcake(cupcakes):
    return {'id': cupcakes.id, 'flavor': cupcakes.flavor, 'size': cupcakes.size, 'rating': cupcakes.rating,
            'image': cupcakes.image}


# display all cupcakes
@app.route('/api/cupcakes')
def list_cupcakes():
    cupcakes = Cupcake.query.all()
    serialized = [serialize_cupcake(cup) for cup in cupcakes]
    return jsonify(cupcakes=serialized)


# display details about a cupcake
@app.route('/api/cupcakes/<int:cupcake_id>')
def get_cupcake(cupcake_id):
    cupcake = Cupcake.query.get_or_404(cupcake_id)
    serialized = serialize_cupcake(cupcake)
    return jsonify(cupcake=serialized)


# take API call, make new cupcake, return JSON of new cupcake
@app.route('/api/cupcakes', methods=['POST'])
def create_cupcake():
    flavor = request.json['flavor']
    size = request.json['size']
    rating = request.json['rating']
    image = request.json['image']
    newcupcake = Cupcake(flavor=flavor, size=size, rating=rating, image=image)
    db.session.add(newcupcake)
    db.session.commit()
    serialized = serialize_cupcake(newcupcake)
    return (jsonify(cupcake=serialized), 201)


# take API call, edit cupcake, return JSON of edited cupcake
@app.route('/api/cupcakes/<int:cupcake_id>', methods=['PATCH'])
def edit_cupcake(cupcake_id):
    cupcake = Cupcake.query.get_or_404(cupcake_id)
    cupcake.flavor = request.json['flavor']
    cupcake.size = request.json['size']
    cupcake.rating = request.json['rating']
    cupcake.image = request.json['image']
    db.session.add(cupcake)
    db.session.commit()
    serialized = serialize_cupcake(cupcake)
    return jsonify(cupcake=serialized)


# delete cupcake from an API call
@app.route('/api/cupcakes/<int:cupcake_id>', methods=['DELETE'])
def delete_cupcake(cupcake_id):
    cupcake = Cupcake.query.get_or_404(cupcake_id)
    db.session.delete(cupcake)
    db.session.commit()
    return jsonify(message="Deleted")


# display home page
@app.route('/')
def home():
    return render_template('index.html')

