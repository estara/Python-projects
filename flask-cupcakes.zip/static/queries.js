const url = "http://localhost:5000/api";

// Make html for each cupcake
function makeHTML(cupcake) {
  return `
    <div cupcakenum=${cupcake.id}>
      <li>
        ${cupcake.flavor} / ${cupcake.size} / ${cupcake.rating}
        <button class="delete-button">Delete</button>
      </li>
      <img src="${cupcake.image}" class="cupcake-img">
    </div>
  `;
}

// create list of cupcakes on website
async function getCupcakes() {
  const response = await axios.get(`${url}/cupcakes`);
  for (let each of response.data.cupcakes) {
    let newCupcake = $(makeHTML(each));
    $("#cupcakelist").append(newCupcake);
  }
}

// handle form to create new cupcake
$("#newcupcakeform").on("submit", async function (evt) {
  evt.preventDefault();

  let flavor = $("#flavor").val();
  let rating = $("#rating").val();
  let size = $("#size").val();
  let image = $("#image").val();

  const newCupcakeResponse = await axios.post(`${url}/cupcakes`, {
    flavor, rating, size, image});

  let newCupcake = $(makeHTML(newCupcakeResponse.data.cupcake));
  $("#cupcakelist").append(newCupcake);
  $("#newcupcakeform").trigger("reset");
});

// delete a cupcake
$("#cupcakelist").on("click", ".delete-button", async function (evt) {
  evt.preventDefault();
  let $cupcake = $(evt.target).closest("div");
  let cupcakeId = $cupcake.attr("cupcakenum");

  await axios.delete(`${url}/cupcakes/${cupcakeId}`);
  $cupcake.remove();
});


$(getCupcakes);