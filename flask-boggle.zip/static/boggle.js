$(function(){

class Boggle{
    constructor(boardId){
      console.log("reading");
        this.score = 0;
        this.words = new Set();
        this.board = $("#", boardId);
        $('.check-word').on('submit', this.handleClick.bind(this));
        $('#boggle').append(`<p id="currentscore">Current score: ${this.score}</p>`)
        setTimeout(this.scoreIt.bind(this), 60000);
    }


async handleClick(evt) {
    evt.preventDefault();
    const $word = $("#guess");
    const guess = $word.val();
    //$(".check-word").reset();
    if (this.words.has(guess)) {
        alert(`Already found ${guess}`, "ok");
        return;
      }
        const response = await axios.get('/check', {params: {'guess': guess}})
if (response.data.result === "ok") {
    this.score += guess.length;
    this.words.add(guess);
    $("#currentscore").html(`<p id="currentscore">Current score: ${this.score}</p>`)
} else if (response.data.result === "not-on-board") {
    alert(`${guess} is not on this board.`);
} else {
    alert(`${guess} is not a valid English word.`);
}}




async scoreIt() {
  console.log("scoring");
    $("#guess").hide();
    const response = await axios.post("/score", { 'score': this.score });
    if (response.data.newRecord) {
      alert(`New record: ${this.score}`, "ok");
    } else {
      alert(`Final score: ${this.score}`, "ok");
    }
  }
}

let game = new Boggle("boggle");

});
