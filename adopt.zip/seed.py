from models import Pet, db
from app import app


db.drop_all()
db.create_all()

Pet.query.delete()

testpet = Pet(name="Squeak", species="porcupine", age=1)

db.session.add(testpet)
db.session.commit()