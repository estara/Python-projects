from flask_wtf import FlaskForm
from wtforms import StringField, FloatField, BooleanField
from wtforms.validators import InputRequired, Optional, URL, AnyOf, NumberRange


class NewPet(FlaskForm):

    name = StringField("pet name")
    species = StringField("pet species", validators=[AnyOf(["cat", "dog", "porcupine"],
                                                          message="Please enter 'cat', 'dog', or 'porcupine'.")])
    photo = StringField("photo url", validators=[Optional(), URL(require_tld=False,
                                                                 message="Please enter a valid URL.")])
    age = FloatField("pet age", validators=[Optional(), NumberRange(min=0, max=30, message="Please enter a valid age.")])
    notes = StringField("notes")


class EditPet(FlaskForm):

    photo_url = StringField("photo url", validators=[Optional(), URL(require_tld=False,
                                                                 message="Please enter a valid URL.")])
    notes = StringField("notes")
    available = BooleanField("Available for adoption")