from flask import Flask, redirect, render_template, request
from flask_debugtoolbar import DebugToolbarExtension
from models import db, connect_db, Pet
from forms import NewPet, EditPet

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql:///adopt'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'foo'

toolbar = DebugToolbarExtension(app)

connect_db(app)
db.create_all()


# display home page
@app.route('/')
def index():
    pets = Pet.query.all()
    return render_template('index.html', pets=pets)


# display add pet form
@app.route('/add')
def addpet():
    form = NewPet()
    return render_template('addpet.html', form=form)


# handle add pet form
@app.route('/add', methods=['POST'])
def addedpet():
    form = NewPet()

    if form.validate_on_submit():
        name = form.name.data
        species = form.species.data
        photo = form.photo.data
        age = form.age.data
        notes = form.notes.data
        newpet = Pet(name=name, species=species, photo_url=photo, age=age, notes=notes)
        db.session.add(newpet)
        db.session.commit()
        return redirect('/')

    else:
        return render_template('/add', form=form)


# display pet details and edit form
@app.route('/<int:petid>')
def editpet(petid):
    pet = Pet.query.get_or_404(petid)
    form = EditPet()
    return render_template('editpet.html', pet=pet, form=form)


# handle edit pet form
@app.route('/<int:petid>', methods=["POST"])
def editedpet(petid):
    pet = Pet.query.get_or_404(petid)
    form = EditPet(obj=pet)

    if form.validate_on_submit():
        pet.photo_url = form.photo_url.data
        pet.notes = form.notes.data
        pet.available = form.available.data
        db.session.commit()
        return redirect('/')

    else:
        return render_template('editpet.html', pet=pet, form=form)