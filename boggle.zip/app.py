from boggle import Boggle
from flask import Flask, session, render_template, jsonify, request


app = Flask(__name__)
app.config["SECRET_KEY"] = "foo"

boggle_game = Boggle()

@app.route("/")
def index():
    board = boggle_game.make_board()
    session['board'] = board
    highscore = session.get("highscore", 0)
    playcount = session.get("playcount", 0)
    return render_template("index.html", board=board, highscore=highscore, playcount=playcount)


@app.route("/check")
def check():
    word = request.args["guess"]
    board = session["board"]
    result = boggle_game.check_valid_word(board, word)
    return jsonify({"result": result})


@app.route("/score")
def setscore():
    score = request.json["score"]
    if score > session["highscore"]:
        session["highscore"] = score
    session["playcount"] += 1
    return jsonify(newRecord=session["highscore"])


