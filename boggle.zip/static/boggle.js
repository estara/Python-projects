$(function(){

class Boggle{
    constructor(boardId){
      console.log("reading");
        this.score = 0;
        this.words = new Set();
        this.board = $("#", boardId);
        const $form = $('form');
        $form.append('<label for="guess">What word did you find?</label>');
        $form.append('<input type="text" id="guess" name="guess" class="guess">');
        $form.append('<input type="submit">');
        $('.check-word', this.board).on('submit', this.handleClick);
        //setTimeout(this.scoreIt.bind(this), 6000);
    }


async handleClick(evt) {
  console.log("checking");
    evt.preventDefault();
    const $word = $("#guess", this.board);
    const info = $word.val();
    console.log(info);
    if (this.words.has(info)) {
        alert(`Already found ${info}`, "ok");
        return;
      } else {
        const response = await axios.get('/check', {data: {word: info}});}
if (response.data.result === "ok") {
    this.score += info.length;
    this.words.add(info);
} else if (response.data.result === "not-on-board") {
    alert(`${info} is not on this board.`);
} else {
    alert(`${info} is not a valid English word.`);
}}




async scoreIt() {
  console.log("scoring");
    $("#guess", this.board).hide();
    const response = await axios.post("/score", { score: this.score });
    if (response.data.newRecord) {
      alert(`New record: ${this.score}`, "ok");
    } else {
      alert(`Final score: ${this.score}`, "ok");
    }
  }
}

let game = new Boggle("boggle");

});
