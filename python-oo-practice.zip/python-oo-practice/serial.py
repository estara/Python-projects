"""Python serial number generator."""


class SerialGenerator:
    """Machine to create unique incrementing serial numbers.
    
    >>> serial = SerialGenerator(start=100)

    >>> serial.generate()
    100

    >>> serial.generate()
    101

    >>> serial.generate()
    102

    >>> serial.reset()

    >>> serial.generate()
    100
    """

    def __init__(self, start):
        # initializes the object
        self.start = start
        self.startover = start

    def generate(self):
        # generates and returns the next serial number
        self.start += 1
        return self.start - 1

    def reset(self):
        # resets the serial numbers to the starting number
        self.start = self.startover
