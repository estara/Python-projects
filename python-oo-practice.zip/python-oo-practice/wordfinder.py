"""Word Finder: finds random words from a dictionary.

>>> foo = WordFinder("./words.txt")
235886 words read

>>> foobar = SpecialWordFinder("./specialwords.txt")
235882 words read

>>> isinstance(foo.random(), str)
True

>>> isinstance(foobar.random(), str)
True
"""
import random

class WordFinder:

    def __init__(self, file):
        # initialize the object and open the word file
        self.lst = []
        self.words = open(file, "r")
        self.readwords()
        self.getlist()

    def readwords(self):
        # create a list of words from the file
        for line in self.words:
            self.lst.append(line.strip())

    def getlist(self):
        # print number of words read
        print("{} words read".format(len(self.lst)))

    def random(self):
        # return a random word
        return random.choice(self.lst)


class SpecialWordFinder(WordFinder):
    # for handling files with blank lines or lines that start with hashtags
    def __init__(self, file):
        super().__init__(file)

    def readwords(self):
        for line in self.words:
            if not line.startswith("#") and line.strip():
                self.lst.append(line.strip())

