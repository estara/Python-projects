from flask import Flask, request, render_template
from stories import *


app = Flask(__name__)

@app.route("/")
def index():
    answers = story.prompts
    return render_template("index.html", prompts=answers)

@app.route("/story")
def makestory():
    text = story.generate(request.args)
    return render_template("story.html", text=text)

