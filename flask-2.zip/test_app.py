import unittest
from app import app


user_data = {
    "name": "John Smith",
    "email": "foo@email.com",
    "year": 1984,
    "color": "red"
}

user_data_bad = {
    "name": None,
    "email": "m",
    "year": 2100,
    "color": "black"
}


class MyTestCase(unittest.TestCase):
    def test_lucky_num(self):
        """Does lucky_num work?"""
        with app.test_client() as client:
            url = "/api/get-lucky-num"
            resp = client.post(url, json=user_data)
            self.assertEqual(resp.status_code, 200)
            data = resp.json
            self.assertIsInstance(data['num']['num'], int)
            self.assertIsInstance(data['year']['year'], int)

    def test_lucky_num_bad_input(self):
        """Does lucky_num return correct errors?"""
        with app.test_client() as client:
            url = "/api/get-lucky-num"
            resp = client.post(url, json=user_data_bad)
            data = resp.json
            self.assertEqual(data, {'errors': {
                'color': ['Invalid value, must be one of: red, green, orange, ''blue.'],
                'email': ['Please enter a valid email.'],
                'name': ['This field is required.'],
                'year': ['Please enter a year between 1900 and 2000.']}})


if __name__ == '__main__':
    unittest.main()
