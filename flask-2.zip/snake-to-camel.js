function snakeToCamel(str) {
    const temp = str.replace(/(?<=_)[a-z]/gi, function (x) {
        return x.toUpperCase();
})
return temp.replace(/_/gi, '')
}

