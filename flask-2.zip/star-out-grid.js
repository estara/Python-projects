function starOutGrid(grid) {
    let idx1 = null
    let idx2 = null
    for (let arr of grid) {
        if (arr.includes('*')) {
            if (idx1 == null) {
            idx1 = arr.indexOf('*');}
            else {
            idx2 = arr.indexOf('*');
            }
            arr.fill('*')
        }
    }
    if (idx1 != idx2 && idx2 != null) {
    for (let arr of grid) {
        arr.fill('*', idx1, idx1+1);
        arr.fill('*', idx2, idx2+1);
    }}
    else if (idx1 != idx2 && idx2 == null) {
        for (let arr of grid) {
        arr.fill('*', idx1, idx1+1);
    }}
    return grid
}