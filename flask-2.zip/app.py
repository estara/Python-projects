from flask import Flask, render_template, request, jsonify
import requests
import random


app = Flask(__name__)
app.config['SECRET_KEY'] = 'foo'


@app.route("/")
def homepage():
    """Show homepage."""
    return render_template("index.html")


def serialize_num(info):
    """serialize num_resp"""
    return {'fact': info['text'], 'num': info['number']}


def serialize_year(info):
    """serialize year_resp"""
    return {'fact': info['text'], 'year': info['number']}


@app.route("/api/get-lucky-num", methods=["GET", "POST"])
def lucky_num():
    """receive request info and send response"""
    name = request.json["name"]
    year = request.json["year"]
    email = request.json["email"]
    color = request.json["color"]
    errors = validation(name, year, email, color)
    if errors:
        return jsonify(errors=errors)
    else:
        number = random.randint(1, 100)
        num_resp = requests.get(f"http://numbersapi.com/{number}/trivia?json")
        year_resp = requests.get(f"http://numbersapi.com/{year}/year?json")
        serialized_num = serialize_num(num_resp.json())
        serialized_year = serialize_year(year_resp.json())
        return jsonify(num=serialized_num, year=serialized_year)


def validation(name, year, email, color):
    """validation tests"""
    errors = {}
    if str == type(name) and len(name) >= 1:
        pass
    else:
        errors["name"] = ["This field is required."]
    if year == '':
        errors["year"] = ["Please enter a year between 1900 and 2000."]
    elif 1900 <= int(year) <= 2000:
        pass
    else:
        errors["year"] = ["Please enter a year between 1900 and 2000."]
    if str == type(email) and len(email) >= 6:
        pass
    else:
        errors["email"] = ["Please enter a valid email."]
    if color == "red" or color == "green" or color == "orange" or color == "blue":
        pass
    else:
        errors["color"] = ["Invalid value, must be one of: red, green, orange, blue."]
    return errors


if __name__ == "__main__":
    app.run(host="0.0.0.0", port="5000", debug=True)