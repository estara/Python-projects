/** processForm: get data from form and make AJAX call to our API. */

async function processForm(evt) {
    evt.preventDefault();
    let name = $("#name").val();
    let year = $("#year").val();
    let email = $("#email").val();
    let color = $("#color").val();
    let response = await axios.post("http://127.0.0.1:5000/api/get-lucky-num", params={"name": name, "year": year, "email": email, "color": color});
    handleResponse(response.data);
    $("#lucky-form").trigger("reset");
}

/** handleResponse: deal with response from our lucky-num API. */

function handleResponse(resp) {
    if ("errors" in resp) {
        if ("name" in resp.errors) {
            $("#name-err").html(resp.errors.name)
        }
        if ("year" in resp.errors) {
            $("#year-err").html(resp.errors.year)
        }
        if ("email" in resp.errors) {
            $("#email-err").html(resp.errors.email)
        }
        if ("color" in resp.errors) {
            $("#color-err").html(resp.errors.color)
        }
    }
    else {
        $("#lucky-results").html(`Your lucky number is ${resp.num.num} (${resp.num.fact}). <br> Your birth year ${resp.year.year} fact is ${resp.year.fact}.`);
    }
    
}


$("#lucky-form").on("submit", processForm);
