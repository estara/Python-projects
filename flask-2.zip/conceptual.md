### Conceptual Exercise

Answer the following questions below:

- What is RESTful routing?
RESTful routing is a set of standards used to create efficient, reusable routes. It aims to map HTTP methods (GET, POST, PATCH, DELETE) and CRUD actions (Create, Read, Update, Destroy) together in a conventional pattern. Instead of relying solely on the URL to indicate what site to visit, a RESTful route depends on the HTTP verb and the URL.

- What is a resource?
An object with a type, associated data, and relationships to other resources.

- When building a JSON API why do you not include routes to render a form that when submitted creates a new user?
JSON can only represent dictionaries, lists, and primitive types. It cannot represent things like SQLAlchemy model instances.

- What does idempotent mean? 
An idempotent operation can be performed many times (with same data) with the result of all calls being the same as if it was done once.

- Which HTTP verbs are idempotent?
GET, PUT/PATCH, DELETE

- What is the difference between PUT and PATCH?
PUT updates an entire resource, PATCH updates part of a resource.

- What is one way encryption?
Trick question. Encryption is a two-way function; what is encrypted can be decrypted with the proper key. Hashing, however, is a one-way function that scrambles plain text to produce a unique message digest. With a properly designed algorithm, it is extremely difficult to reverse the hashing process to reveal the original password.

- What is the purpose of a `salt` when hashing a password?
Salt is a random string introduced before hashing to create a unique password. Salts help us mitigate hash table attacks by forcing attackers to re-compute them using the salts for each user.

- What is the purpose of the Bcrypt module?
Bcrypt is used to hash passwords.

- What is the difference between authorization and authentication?
Authentication confirms that users are who they say they are. Authorization gives those users permission to access a resource.
