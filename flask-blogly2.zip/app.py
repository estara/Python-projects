"""Blogly application."""

from flask import Flask, redirect, render_template, request
from flask_debugtoolbar import DebugToolbarExtension
from models import db, connect_db, User, Post

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql:///blogly'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'foo'

toolbar = DebugToolbarExtension(app)

connect_db(app)
db.create_all()


@app.route('/')
def index():
    return redirect('/users')


@app.route('/users')
def listusers():
    userlist = User.query.all()
    return render_template('/userlisting.html', users=userlist)


@app.route('/users/new')
def newuser():
    return render_template('/newuser.html')


@app.route('/users/new', methods=['POST'])
def adduser():
    first = request.form['first']
    last = request.form['last']
    url = request.form['url']
    user = User(first_name=first, last_name=last, image_url=url)
    db.session.add(user)
    db.session.commit()
    return redirect('/users')


@app.route('/users/<int:userid>')
def userdetail(userid):
    user = User.query.get_or_404(userid)
    postlist = Post.query.filter(Post.created_by == userid)
    return render_template('/userdetail.html', user=user, posts=postlist)


@app.route('/users/<int:userid>/edit')
def edituser(userid):
    user = User.query.get_or_404(userid)
    return render_template('/edituser.html', user=user)


@app.route('/users/<int:userid>/edit', methods=['POST'])
def makeedit(userid):
    user = User.query.get_or_404(userid)
    user.first_name = request.form['first']
    user.last_name = request.form['last']
    user.image_url = request.form['url']
    db.session.add(user)
    db.session.commit()
    return redirect('/users')


@app.route('/users/<int:userid>/delete', methods=['POST'])
def deleteuser(userid):
    user = User.query.get_or_404(userid)
    db.session.delete(user)
    db.session.commit()
    return redirect('/users')


@app.route('/users/<int:userid>/posts/new')
def newpost(userid):
    user = User.query.get_or_404(userid)
    return render_template('/newpost.html', user=user)


@app.route('/users/<int:userid>/posts/new', methods=['POST'])
def addpost(userid):
    user = User.query.get_or_404(userid)
    title = request.form['title']
    content = request.form['content']
    post = Post(title=title, content=content, user=user)
    db.session.add(post)
    db.session.commit()
    return redirect(f'/users/{userid}')


@app.route('/posts/<int:postid>')
def postdetail(postid):
    post = Post.query.get_or_404(postid)
    return render_template('/postdetail.html', post=post)


@app.route('/posts/<int:postid>/edit')
def editpost(postid):
    post = Post.query.get_or_404(postid)
    return render_template('/editpost.html', post=post)


@app.route('/posts/<int:postid>/edit', methods=['POST'])
def makepostedit(postid):
    post = Post.query.get_or_404(postid)
    post.title = request.form['title']
    post.content = request.form['content']
    db.session.add(post)
    db.session.commit()
    return redirect(f'/posts/{postid}')


@app.route('/posts/<int:postid>/delete', methods=['POST'])
def deletepost(postid):
    post = Post.query.get_or_404(postid)
    db.session.delete(post)
    db.session.commit()
    return redirect('/users')