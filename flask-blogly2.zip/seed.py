from models import User, db, Post
from app import app


db.drop_all()
db.create_all()

User.query.delete()

johnny = User(first_name="John", last_name="Smith", image_url="https://unsplash.com/photos/Uq5i5_cQdr8")

db.session.add(johnny)
db.session.commit()