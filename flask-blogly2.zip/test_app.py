from unittest import TestCase
from app import app
from models import db, User, Post


app.config['SQLALCHEMY_DATABASE_URI']= 'postgresql:///blogly_test'

db.drop_all()
db.create_all()


class TestCases(TestCase):

    def setUp(self):
        User.query.delete()
        Post.query.delete()
        user = User(first_name='Joby', last_name='Wu', image_url='https://ohpv.org/wp-content/uploads/2018/12/EventPic-1024x242.png')
        post = Post(title="random", content="blah blah")
        db.session.add(user, post)
        db.session.commit()
        self.user_id = user.id

    def tearDown(self):
        db.session.rollback()

    def test_listusers(self):
        with app.test_client() as client:
            resp = client.get('/users')
            html = resp.get_data(as_text=True)
            self.assertEqual(resp.status_code, 200)
            self.assertIn('<h1>Users</h1>', html)
            self.assertIn('Joby Wu', html)

    def test_userdetail(self):
        with app.test_client() as client:
            resp = client.get(f'/userdetail/{self.user_id}')
            html = resp.get_data(as_text=True)
            self.assertEqual(resp.status_code, 200)
            self.assertIn('Joby Wu', html)

    def test_adduser(self):
        with app.test_client() as client:
            foo = {'first_name': 'Foo', 'last_name': 'Bar', 'image_url': 'https://ohpv.org/wp-content/uploads/2018/12/EventPic-1024x242.png'}
            resp = client.post('/users/new', data=foo, follow_redirects=True)
            html = resp.get_data(as_text=True)
            self.assertEqual(resp.status_code, 200)
            self.assertIn('Foo Bar', html)

    def test_newuser(self):
        with app.test_client() as client:
            resp = client.get('/newuser')
            html = resp.get_data(as_text=True)
            self.assertEqual(resp.status_code, 200)
            self.assertIn('<h1>Create a user</h1>', html)

    def test_addpost(self):
        with app.test_client() as client:
            foo = {'title': 'moo', 'content': 'says the cow', 'user': f'{self.user_id}'}
            resp = client.post('/users/<int:userid>/posts/new', data=foo, follow_redirects=True)
            html = resp.get_data(as_text=True)
            self.assertEqual(resp.status_code, 200)
            self.assertIn('moo', html)

    def test_newpost(self):
        with app.test_client() as client:
            resp = client.get('/newpost')
            html = resp.get_data(as_text=True)
            self.assertEqual(resp.status_code, 200)
            self.assertIn('<h1>Add Post for', html)