"""Message model tests"""

# run these tests like:
#
#    python -m unittest test_user_model.py


import os
from unittest import TestCase

from models import db, User, Message, Follows, Likes

# BEFORE we import our app, let's set an environmental variable
# to use a different database for tests (we need to do this
# before we import our app, since that will have already
# connected to the database

os.environ['DATABASE_URL'] = "postgresql:///warbler-test"


# Now we can import app

from app import app, CURR_USER_KEY

# Create our tables (we do this here, so we only create the tables
# once for all tests --- in each test, we'll delete the data
# and create fresh new clean test data

db.create_all()


class MessageModelTestCase(TestCase):
    """Test views for messages."""

    def setUp(self):
        """Create test client, add sample data."""

        User.query.delete()
        Message.query.delete()
        Follows.query.delete()

        self.client = app.test_client()
        self.testuser = User.signup(username="testuser",
                                    email="test@test.com",
                                    password="testuser",
                                    image_url=None)
        db.session.commit()
        m = Message(
            text="test123",
            user_id=self.testuser.id
        )
        db.session.add(m)
        db.session.commit()

    def tearDown(self):
        db.session.rollback()

    def test_message_model(self):
        """Does basic model work?"""
        with self.client as c:
            with c.session_transaction() as sess:
                sess[CURR_USER_KEY] = self.testuser.id
        m = Message.query.filter_by(text="test123").one()
        self.assertEqual(m.text, "test123")
        self.assertEqual(m.user_id, self.testuser.id)

    def test_message_likes(self):
        """Does Likes model work?"""
        m1 = Message(
            text="foobar",
            user_id=self.testuser.id
        )
        m2 = Message(
            text="meh city",
            user_id=self.testuser.id
        )
        u = User.signup("test2", "test2@email.com", "password", None)
        u.id = 951
        db.session.add_all([m1, m2, u])
        db.session.commit()
        u.likes.append(m1)
        db.session.commit()
        likes = Likes.query.filter(Likes.user_id == u.id).all()
        self.assertEqual(len(likes), 1)
        self.assertEqual(likes[0].message_id, m1.id)
