"""User View tests"""

# run these tests like:
#
#    FLASK_ENV=production python -m unittest test_message_views.py


import os
from unittest import TestCase

from models import db, connect_db, Message, User, Likes, Follows

# BEFORE we import our app, let's set an environmental variable
# to use a different database for tests (we need to do this
# before we import our app, since that will have already
# connected to the database

os.environ['DATABASE_URL'] = "postgresql:///warbler-test"


# Now we can import app

from app import app, CURR_USER_KEY

# Create our tables (we do this here, so we only create the tables
# once for all tests --- in each test, we'll delete the data
# and create fresh new clean test data

db.create_all()

# Don't have WTForms use CSRF at all, since it's a pain to test

app.config['WTF_CSRF_ENABLED'] = False


class UserViewTestCase(TestCase):
    """Test views for users."""

    def setUp(self):
        """Create test client, add sample data."""

        User.query.delete()
        Message.query.delete()

        self.client = app.test_client()

        self.testuser = User.signup(username="testuser",
                                    email="test@test.com",
                                    password="testuser",
                                    image_url=None)
        self.testuser.id = 6541
        self.tu2 = User.signup("test2", "test2@test.com", "password", None)
        self.tu2.id = 1597
        self.tu3 = User.signup("test3", "test3@test.com", "password", None)
        self.tu3.id = 9578
        self.tu4 = User.signup("test4", "test4@test.com", "password", None)
        self.tu5 = User.signup("test5", "test5@test.com", "password", None)
        db.session.commit()
        self.m2 = Message(text="yahoo cowboy", user_id=self.testuser.id)
        self.m3 = Message(text="daffodils in spring", user_id=self.testuser.id)
        self.m4 = Message(id=456789, text="holy hail batman", user_id=self.tu2.id)
        db.session.add(self.m2)
        db.session.add(self.m3)
        db.session.add(self.m4)
        db.session.commit()
        self.f1 = Follows(user_being_followed_id=self.tu2.id, user_following_id=self.testuser.id)
        self.f2 = Follows(user_being_followed_id=self.tu3.id, user_following_id=self.testuser.id)
        self.f3 = Follows(user_being_followed_id=self.testuser.id, user_following_id=self.tu2.id)
        db.session.add(self.f1)
        db.session.add(self.f2)
        db.session.add(self.f3)
        db.session.commit()

    def tearDown(self):
        """Teardown session"""
        db.session.rollback()

    def test_list_users(self):
        """Can list users?"""
        with self.client as c:
            with c.session_transaction() as sess:
                sess[CURR_USER_KEY] = self.testuser.id
            resp = c.get("/users")
            html = resp.get_data(as_text=True)
            self.assertEqual(resp.status_code, 200)
            self.assertIn('<div class="row" id="indexpage">', html)

    def test_users_show(self):
        """Can show user?"""
        with self.client as c:
            with c.session_transaction() as sess:
                sess[CURR_USER_KEY] = self.testuser.id
            resp = c.get(f"/users/{self.testuser.id}")
            html = resp.get_data(as_text=True)
            self.assertEqual(resp.status_code, 200)
            self.assertIn('<ul class="list-group" id="messages">', html)

    def test_add_like(self):
        """Can add likes?"""
        m = Message(id=1234, text="Thor the god of thunder", user_id=self.tu2.id)
        db.session.add(m)
        db.session.commit()
        with self.client as c:
            with c.session_transaction() as sess:
                sess[CURR_USER_KEY] = self.testuser.id
            resp = c.post("/users/add_like/1234", follow_redirects=True)
            self.assertEqual(resp.status_code, 200)
            likes = Likes.query.filter(Likes.message_id == 1234).all()
            self.assertEqual(len(likes), 1)
            self.assertEqual(likes[0].user_id, self.testuser.id)

    def test_remove_like(self):
        """Can remove like?"""
        m = Message.query.filter(Message.text == "daffodils in spring").one()
        self.assertIsNotNone(m)
        self.assertNotEqual(m.user_id, self.tu2.id)
        with self.client as c:
            with c.session_transaction() as sess:
                sess[CURR_USER_KEY] = self.testuser.id
            c.post(f"/users/add_like/{m.id}")
            l = Likes.query.filter(Likes.message_id == m.id).all()
            self.assertIsNotNone(l)
            resp = c.post(f"/users/add_like/{m.id}", follow_redirects=True)
            likes = Likes.query.filter(Likes.message_id == m.id).all()
            self.assertEqual(len(likes), 0)
            self.assertEqual(resp.status_code, 200)

    def test_unauthenticated_like(self):
        """Can like without authorization?"""
        m = Message.query.filter(Message.text == "yahoo cowboy").one()
        self.assertIsNotNone(m)
        with self.client as c:
            resp = c.post(f"/users/add_like/{m.id}", follow_redirects=True)
            self.assertEqual(200, resp.status_code)
            self.assertIn("Access unauthorized", str(resp.data))

    def test_show_following(self):
        """Can display who user is following?"""
        with self.client as c:
            with c.session_transaction() as sess:
                sess[CURR_USER_KEY] = self.testuser.id
            resp = c.get(f"/users/{self.testuser.id}/following")
            self.assertEqual(200, resp.status_code)
            self.assertIn("@test2", str(resp.data))
            self.assertIn("@test3", str(resp.data))
            self.assertNotIn("@test4", str(resp.data))
            self.assertNotIn("@test5", str(resp.data))

    def test_users_followers(self):
        """Can display who is following user?"""
        with self.client as c:
            with c.session_transaction() as sess:
                sess[CURR_USER_KEY] = self.testuser.id
            resp = c.get(f"/users/{self.testuser.id}/followers")
            self.assertIn("test2", str(resp.data))
            self.assertNotIn("@test3", str(resp.data))
            self.assertNotIn("@test4", str(resp.data))
            self.assertNotIn("@test5", str(resp.data))

    def test_unauthorized_following_page_access(self):
        """Can display who user is following without authorization?"""
        with self.client as c:
            resp = c.get(f"/users/{self.testuser.id}/following", follow_redirects=True)
            self.assertEqual(resp.status_code, 200)
            self.assertNotIn("@test2", str(resp.data))
            self.assertIn("Access unauthorized", str(resp.data))

    def test_unauthorized_followers_page_access(self):
        """Can display who is following user without authorization?"""
        with self.client as c:
            resp = c.get(f"/users/{self.testuser.id}/followers", follow_redirects=True)
            self.assertEqual(resp.status_code, 200)
            self.assertNotIn("@test2", str(resp.data))
            self.assertIn("Access unauthorized", str(resp.data))
