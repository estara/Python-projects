"""User model tests."""

# run these tests like:
#
#    python -m unittest test_user_model.py


import os
from unittest import TestCase
from sqlalchemy import exc
from models import db, User, Message, Follows, Likes

# BEFORE we import our app, let's set an environmental variable
# to use a different database for tests (we need to do this
# before we import our app, since that will have already
# connected to the database

os.environ['DATABASE_URL'] = "postgresql:///warbler-test"


# Now we can import app

from app import app

# Create our tables (we do this here, so we only create the tables
# once for all tests --- in each test, we'll delete the data
# and create fresh new clean test data

db.create_all()


class UserModelTestCase(TestCase):
    """Test views for users."""

    def setUp(self):
        """Create test client, add sample data."""

        User.query.delete()
        Message.query.delete()
        Follows.query.delete()

        self.user2 = User.signup(
            email="test2@test.com",
            username="testuser2",
            password="password",
            image_url=None
        )
        self.user3 = User(
            email="test3@test.com",
            username="testuser3",
            password="password"
        )
        db.session.add(self.user2)
        db.session.add(self.user3)
        db.session.commit()
        self.client = app.test_client()

    def tearDown(self):
        """tear down session"""
        db.session.rollback()

    def test_user_model(self):
        """Does basic model work?"""

        self.user = User.signup(
            email="test@test.com",
            username="testuser",
            password="password",
            image_url=None
        )

        db.session.commit()

        # User should have no messages & no followers
        self.assertEqual(len(self.user.messages), 0)
        self.assertEqual(len(self.user.followers), 0)
        self.assertEqual(len(self.user.likes), 0)

    def test_repr(self):
        """Does __repr__ work?"""
        u3 = repr(self.user3)
        self.assertIn("test3", u3)
        self.assertIn("testuser3", u3)

    def test_user_follows(self):
        """Does user follows work?"""
        self.user3.following.append(self.user2)
        db.session.add(self.user3)
        db.session.commit()
        self.assertEqual(len(self.user2.following), 0)
        self.assertEqual(len(self.user2.followers), 1)
        self.assertEqual(len(self.user3.followers), 0)
        self.assertEqual(len(self.user3.following), 1)
        self.assertEqual(self.user2.followers[0].id, self.user3.id)
        self.assertEqual(self.user3.following[0].id, self.user2.id)

    def test_is_following(self):
        """Does user following work?"""
        self.user3.following.append(self.user2)
        db.session.add(self.user3)
        db.session.commit()
        self.assertTrue(self.user3.is_following(self.user2))
        self.assertFalse(self.user2.is_following(self.user3))

    def test_is_followed_by(self):
        """Does being followed work?"""
        self.user3.following.append(self.user2)
        db.session.add(self.user3)
        db.session.commit()
        self.assertTrue(self.user2.is_followed_by(self.user3))
        self.assertFalse(self.user3.is_followed_by(self.user2))

    def test_signup(self):
        """Does signup work?"""
        user = User.signup("test4", "test4@test.com", "password", None)
        user.id = 987654
        db.session.commit()
        testuser = User.query.get(user.id)
        self.assertIsNotNone(testuser)
        self.assertEqual(testuser.username, "test4")
        self.assertEqual(testuser.email, "test4@test.com")
        self.assertNotEqual(testuser.password, "password")

    def test_signup_username_bad(self):
        """Does signup fail with bad username?"""
        bad = User.signup(None, "testbad@test.com", "password", None)
        bad.id = 123456789
        with self.assertRaises(exc.IntegrityError) as context:
            db.session.commit()

    def test_signup_email_bad(self):
        """Does signup fail with bad email?"""
        bad = User.signup("testbad", None, "password", None)
        bad.id = 951753
        with self.assertRaises(exc.IntegrityError) as context:
            db.session.commit()

    def test_signup_password_bad(self):
        """Does signup fail with bad password?"""
        with self.assertRaises(ValueError) as context:
            User.signup("testbad", "testbad@test.com", "", None)
        with self.assertRaises(ValueError) as context:
            User.signup("testbad1", "testbad1@test.com", None, None)

    def test_user_authentication(self):
        """Does user authentication work?"""
        usera = User.authenticate(self.user2.username, "password")
        self.assertIsNotNone(usera)
        self.assertEqual(usera.id, self.user2.id)

    def test_invalid_username(self):
        """Does a bad username fail?"""
        self.assertFalse(User.authenticate("badusername", "password"))

    def test_wrong_password(self):
        """Does a bad password fail?"""
        self.assertFalse(User.authenticate(self.user2.username, "badpassword"))
