def same_frequency(num1, num2):
    """Do these nums have same frequencies of digits?
    
        >>> same_frequency(551122, 221515)
        True
        
        >>> same_frequency(321142, 3212215)
        False
        
        >>> same_frequency(1212, 2211)
        True
    """
    counts1 = {}
    counts2 = {}
    for num in str(num1):
        if num in counts1:
            counts1[num] += 1
        else:
            counts1[num] = 1
    for num in str(num2):
        if num in counts2:
            counts2[num] += 1
        else:
            counts2[num] = 1
    return counts1 == counts2