from flask import Flask, request

app = Flask(__name__)

@app.route('/welcome')
def welcome():
    html = "<html>welcome</html>"
    return html

@app.route('/welcome/home')
def welcome_home():
    html = "<html>welcome home</html>"
    return html

@app.route('/welcome/back')
def welcome_back():
    html = "<html>welcome back</html>"
    return html
