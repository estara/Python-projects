from flask import Flask, render_template, flash, redirect, request, session
from surveys import *



app = Flask(__name__)
app.config["SECRET_KEY"] = "foo"

responses = "blank"
qnum = 0


@app.route("/")
def index():
    title = satisfaction_survey.title
    instructions = satisfaction_survey.instructions
    return render_template("base.html", title=title, instructions=instructions)

@app.route("/setsession", methods=["GET", "POST"])
def setsession():
    session[responses] = []
    return redirect("questions/0")


@app.route("/questions/<num>")
def questions(num):
    resps = session.get(responses)
    if len(resps) >= len(satisfaction_survey.questions):
        return redirect("/thanks")
    elif len(resps) != int(num):
        flash("Redirecting")
        return redirect("/questions/{0}".format(len(resps)))
    if satisfaction_survey.questions[int(num)]:
        global qnum
        qnum += 1
        question = satisfaction_survey.questions[int(num)]
        return render_template("response.html", question_num=int(num), question=question)
    return redirect("/thanks")


@app.route("/answer", methods=["GET", "POST"])
def answer():
    ans = request.form["answer"]
    resps = session[responses]
    resps.append(ans)
    session[responses] = resps
    return redirect("/questions/{0}".format(qnum))


@app.route("/thanks")
def thanks():
    html = """
    <!DOCTYPE html>
    <html>
        <body>
            <h1> Thank you!</h1>
        </body>
    </html>"""
    return html

